import { getStore } from "@netlify/blobs";

const json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" },
  body: JSON.stringify(body),
});

export default async (req) => {
  if (req.httpMethod === "OPTIONS") return { statusCode: 204, headers: { "Access-Control-Allow-Methods": "GET, PUT, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" }, body: "" };
  const store = getStore("stock-alat-kebersihan");
  if (req.httpMethod === "GET") {
    const saved = await store.get("transactions", { type: "json" });
    return json(200, { data: Array.isArray(saved) ? saved : [] });
  }
  if (req.httpMethod === "PUT") {
    try {
      const parsed = JSON.parse(req.body || "{}");
      if (!Array.isArray(parsed.data)) return json(400, { error: "Format data tidak valid." });
      if (JSON.stringify(parsed.data).length > 2_000_000) return json(413, { error: "Data terlalu besar." });
      await store.setJSON("transactions", parsed.data);
      return json(200, { ok: true });
    } catch {
      return json(400, { error: "Data tidak dapat dibaca." });
    }
  }
  return { statusCode: 405, headers: { Allow: "GET, PUT, OPTIONS" }, body: "Method not allowed" };
};

export const config = { path: "/.netlify/functions/stock-data" };
